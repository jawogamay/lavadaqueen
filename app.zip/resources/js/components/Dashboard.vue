<template>
    <div class="container-fluid">
        <h1> Hi Dashboard </h1>
    </div>
</template>