<template>
  <div>
    <GmapMap
  :center="{lat:10.3139, lng:123.9012}"
  :zoom="17"
  map-type-id="terrain"
  style="width: 100%; height: 100vh"
>
  <GmapMarker
    :key="index"
    v-for="(m, index) in markers"
    :position="m.position"
    :clickable="true"
    :draggable="true"
    @click="center=m.position"
  />
</GmapMap>
</div>
</template>