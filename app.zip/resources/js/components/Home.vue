<template>
    <div class="conatiner-fluid">
        <div class="card" v-if="$gate.customer()">
            <h1> Test </h1>
        </div>
    </div>
</template>