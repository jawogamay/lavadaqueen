<?php $__env->startSection('content'); ?>
        
        <private-chat :user="<?php echo e(auth()->user()); ?>"></private-chat>
        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\lovehunoncaps\resources\views/private.blade.php */ ?>