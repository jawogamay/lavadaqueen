<?php echo e($slot); ?>: <?php echo e($url); ?>


<?php /* C:\laragon\www\lovehunoncaps\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php */ ?>