<?php echo e($slot); ?>


<?php /* C:\laragon\www\lovehunoncaps\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>