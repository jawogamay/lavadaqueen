<!DOCTYPE html>
<html>
<head>
<title>Lovehunon</title>
<!-- Meta-Tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Deterge Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Meta-Tags -->
<!-- Custom-Stylesheet-Links -->
<!-- Bootstrap-CSS --> <link href="/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Font-awesome-CSS -->  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
     <link href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900|Material+Icons' rel="stylesheet">
<!-- Banner-slider-CSS --> <link rel="stylesheet" type="text/css" href="/css/zoomslider.css" />
<!-- Owl-carousel-CSS --><link href="/css/owl.carousel.css" rel="stylesheet">
<!-- Index-Page-CSS --><link href="/css/index.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom-Stylesheet-Links -->
<!--web-fonts-->
<!-- Logo-font --><link href="//fonts.googleapis.com/css?family=Hind+Vadodara:300,400,500,600,700" rel="stylesheet">
<!-- Body-font --><link href="//fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
<!-- Headings-font --><link href="//fonts.googleapis.com/css?family=Cabin+Sketch:400,700" rel="stylesheet">
<!--//web-fonts-->
<!--//fonts-->
<!-- js -->
</head>
<body>
<!-- header -->
    <div id="demo-1" data-zs-src='["images/4.jpg", "images/2.jpg", "images/1.jpg","images/3.jpg"]' data-zs-overlay="dots">
        <div class="demo-inner-content">
        <!--/header-w3l-->
        <div class="header-w3-agileits" id="home">
    <div class="w3-header-bottom">
        <div class="container"> 
                <h1><a href="index.html"><span class="letter">L</span>avada<span class="letter">Q</span>ueen<span class="square"></span></a></h1> 
            <div class="header-w3-top">
                <div class="agileinfo-phone">
                <div class="phone-wthree-left">
                    
                    <i class="fa fa-volume-control-phone" aria-hidden="true"></i>
                    <p>Want a Launder...? <span>call us now!</span></p>
                </div>
                 <h2> +63 (32) 5142788</h2>

                </div>
            </div>
            <div class="top-nav">
                        <nav class="navbar navbar-default">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li class="first-list"><a href="/">Home</a></li>
                                    <li><a href="/about-us">About</a></li>
                                    <li><a href="/services">Services</a></li>
                                    <li><a href="/contacts">Contact</a></li>
                                    <li><a href="/login">Login</a></li>
                                      <li><a href="/register">Register</a></li>
                                </ul>   
                                <div class="clearfix"> </div>
                            </div>  
                        </nav>      
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
    <!--//header-w3l-->
    <!--/banner-info-->
        <div class="agile-baner-info-w3ls">            
            <h3>We Offer Quality Dry Cleaning at Competitive Prices <span></span></h3>
            <div class="clearfix"> </div>
            <div class="bnr-agileits-w3layouts-btn">
                <a href="#" class="button-w3layouts hvr-rectangle-out" data-toggle="modal" data-target="#myModal">Read more</a>
            </div>
        </div>
    <!--/banner-info-->
        </div>
           </div>
    </div>


    <main>
        @yield('content')
    </main>

    <div class="footer w3layouts">
        <div class="container">
            <div class="footer-row w3layouts-agile">
               
                <div class="col-md-3 footer-grids w3l-agileits">
                    <h3>Main Branch</h3>
                    <p>1F. Sotto Drive,</p>
                    <p>Cebu City,</p>
                    <p>6000, Philippines</p>
                </div>
                <div class="col-md-3 footer-grids w3l-agileits">
                    <h3>Connect with us</h3>
                    <div class="agileinfo-social-grids">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                            <li><a href="#"><i class="fa fa-vk"></i></a></li>
                        </ul>
                    </div>
                    <div class="bottons-agileits-w3layouts">
                        <a class="btn1-w3-agileits" href="/login" data-toggle="modal"><i class="fa fa-sign-in" aria-hidden="true"></i>Login</a>.
                        <a class="btn2-w3-agileits" href="/register" data-toggle="modal"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Register</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="col-md-3 footer-grids w3l-agileits">    
                    <h3>Questions....?</h3>
                    <p>+0 123 456 789<p>
                    <p><a href="mailto:info@example.com">mail@example.com</a></p>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
<!--//footer--> 
<!-- copy-right -->
        <div class="copyright-wthree">
            <div class="container">
                <ul class="b-nav">
                    <li><a href="/">Home</a></li>
                    <li><a href="/about-us" >About</a></li>
                    <li><a href="/services">Services</a></li>
                    <li><a href="/contacts">Contact</a></li>
                </ul>
                <p>&copy; 2019 Lavada Queen . All Rights Reserved | Design by <a href="http://w3layouts.com/"> W3layouts </a></p>
            </div>
        </div>

    <!-- //smooth scrolling -->
<script type="text/javascript" src="/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="/js/modernizr-2.6.2.min.js"></script>
<script type="text/javascript" src="/js/jquery.zoomslider.min.js"></script>
<!-- requried-jsfiles-for owl -->
 <script src="/js/owl.carousel.js"></script>
                                    <script>
                                        $(document).ready(function() {
                                          $("#owl-demo2").owlCarousel({
                                            items : 1,
                                            lazyLoad : false,
                                            autoPlay : true,
                                            navigation : false,
                                            navigationText : false,
                                            pagination : true,
                                          });
                                        });
                                      </script>
                             <!-- //requried-jsfiles-for owl -->
 <!-- start-smoth-scrolling -->
<script type="text/javascript" src="/js/move-top.js"></script>
<script type="text/javascript" src="/js/easing.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(".scroll").click(function(event){     
            event.preventDefault();
            $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
        });
    });
</script>
<!-- start-smoth-scrolling -->
<!-- here stars scrolling icon -->
    <script type="text/javascript">
        $(document).ready(function() {
            /*
                var defaults = {
                containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
                };
            */
                                
            $().UItoTop({ easingType: 'easeOutQuart' });
                                
            });
    </script>
<!-- //here ends scrolling icon -->
<!--js for bootstrap working-->
    <script src="/js/bootstrap.js"></script>
<!-- //for bootstrap working -->
</body>
</html>